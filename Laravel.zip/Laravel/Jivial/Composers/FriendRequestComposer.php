<?php namespace Jivial\Composers;

use Jivial\Repositories\FriendRepository;

class FriendRequestComposer {

    /**
     * Friend Repository
     *
     * @var FriendRepository
     */
    protected $friend;

    /**
     * Init dependencies
     *
     * @param FriendRepository $friend
     */
    public function __construct(FriendRepository $friend)
    {
        $this->friend = $friend;
    }

    /**
     * View composer for Friend Repository
     *
     * @param  View $view View object
     * @return void
     */
    public function compose($view)
    {
        $friendRequest = $this->friend->getFriendRequestCount();
        $view->with('friendRequest', $friendRequest);
    }
}