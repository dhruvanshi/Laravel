<?php namespace Jivial\Models;

use Jivial\Traits\MagicPropertiesTrait;

/**
 * Class Friend
 * @package Jivial
 */
class Friend
{

	use MagicPropertiesTrait {
		__get as magicGet;
	}

	protected $user;

	public function __construct($user)
	{
		$this->user = $user;
	}

	public function getRelationshipTypeAttribute()
	{
		return $this->user->pivot->relationship_type;
	}

	public function __get($property)
	{
		if (! is_null($this->magicGet($property))) {
			return $this->magicGet($property);
		}
		return $this->user->{$property};
	}

	public function __call($method, $parameters)
	{
		return call_user_func_array([$this->user, $method], $parameters);
	}

}
