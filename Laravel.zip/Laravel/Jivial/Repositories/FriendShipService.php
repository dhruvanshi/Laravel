<?php namespace Jivial\Services;

use Jivial\Services\BaseService;
use Illuminate\Cache\Repository as Cache;
use Jivial\Services\Validation\FriendValidator as Validator;
use Illuminate\Session\SessionManager as Session;
use Jivial\Repositories\FriendRepository;

/**
 * Class FriendShipService
 * @package Jivial
 */
class FriendShipService extends BaseService {

    /**
     * Friend Repository
     *
     * @var FriendRepository
     */
    protected $friend;

    /**
     * Validation Service
     *
     * @var FriendValidator
     */
    protected $valid;

    /**
     * Cache repository
     *
     * @var Illuminate\Cache\Repository
     */
    protected $cache;

    /**
     * Session store
     *
     * @var Illuminate\Session\SessionManager
     */
    protected $session;

    /**
     * Class Constructor
     *
     * @param FriendRepository $friend Friend Object
    */
    public function __construct(FriendRepository $friend, Validator $valid, Cache $cache, Session $session)
    {
        $this->friend  = $friend;
        $this->valid   = $valid;
        $this->cache   = $cache;
        $this->session = $session;
    }

    /**
     * Call the Repo for the update friend relation
     *
     * @param object $user User Model
     * @param int $friendId Friend Id
     * @param int $relation Description
     * @return  array Success and message
     */
    public function updateFriend($user, $friendId, $relation)
    {
        $friend = false;

        // Will return true if successful
        $friend = $this->friend->updateFriendRelation($user, $friendId, $relation);

        // set the default responses
        $successResponse = ['success' => true, 'message' => 'Your Friend Relation changed.', 'action' => 'friend_relation_change', 'friend' => md5($friendId), 'relation' => $relation];
        $failureResponse = ['success' => false, 'message' => 'Please try again'];
        return ($friend) ? $successResponse : $failureResponse;
    }

    /**
     * Call the Repo for the unfriend
     *
     * @param object $user User Model
     * @param int $friendId Friend Id
     * @return array Success and message
     */
    public function unFriend($user, $friendId)
    {
        $friend = false;

        // Will return true if successful
        $friend = $this->friend->deleteFriend($user, $friendId);

        // set the default responses
        $successResponse = ['success' => true, 'message' => 'Your have successfully Unfriend.', 'friend_id' => $friendId, 'action' => 'unfriend'];
        $failureResponse = ['success' => false, 'message' => 'Please try again'];
        return ($friend) ? $successResponse : $failureResponse;
    }

    /**
     * Accept friend Request
     *
     * @param object $user
     * @param int $fromId Requested Friend Id
     * @param int $status Status
     * @param string $friendType
     * @return array Success and message
     */
    public function acceptFriendRequest($user, $fromId, $status, $friendType)
    {
        $request = false;

        $friendRequest = $this->friend->getFriendRequestInfo($user, $fromId);
        $rfrType = $friendRequest->pivot->relationship_type;

        // Will return true if successful
        $request = $this->friend->acceptFriendRequest($user, $fromId, $status, $friendType, $rfrType);

        // set the default responses
        $successResponse = ['success' => true, 'message' => 'Your have successfully Accept Friend Request.', 'friend_id' => $fromId, 'action' => 'assept_request'];
        $failureResponse = ['success' => false, 'message' => 'Please try again'];
        return ($request) ? $successResponse : $failureResponse;
    }

    /**
     * Decline Friend Request
     *
     * @param object $user
     * @param int $fromId Requested Friend Id
     * @param int $status Status
     * @return array Success and message
    */
    public function declineFriendRequest($user, $fromId, $status)
    {
        $request = false;

        // Will return true if successful
        $request = $this->friend->declineFriendRequest($user, $fromId, $status);

        // set the default responses
        $successResponse = ['success' => true, 'message' => 'Your have successfully Accept Decline Request.', 'friend_id' => $fromId, 'action' => 'decline_request'];
        $failureResponse = ['success' => false, 'message' => 'Please try again'];
        return ($request) ? $successResponse : $failureResponse;
    }

    /**
     * Search friend
     *
     * @param object $user
     * @param string $q
     * @return array or boolean
     */
    public function searchFriend($user, $q)
    {
        $search = false;

        //will return object of Friend
        $search = $this->friend->searchFriend($user, $q);

        $result = [];
        if ($search) {
            foreach ($search as $row) :
                $result[] = ['friend_id' => $row->pivot->friend_id,'name' => $row->full_name, 'imageURL' => $row->image];
            endforeach;

            return $result;
        }
        return false;
    }

    /**
     * Get Friend By Friend Id
     *
     * @param object $user
     * @param int $friend_id
     * @return array
     */
    public function getFriendByFriendId($user, $friend_id)
    {
        $friend = false;

        $friend = $this->friend->getFriendByFriendId($user, $friend_id);

        $response = [];
        if ($friend) {
            $response['full_name']              = $friend->full_name;
            $response['relationship_type']      = $friend->pivot->relationship_type;
            $response['slug']                   = route('topics', ['userslug' => $friend->slug]);
            $response['change_friend_relation'] = route('friends.change_relation', ['userslug' => $friend->slug]);
            $response['friend_id']              = $friend->pivot->friend_id;
            $response['hash_friend_id']         = md5($friend->pivot->friend_id);
            $response['success']                = true;
            $response['image']                  = $friend->image;
            $response['message']                = 'You have get Friend successfully.';
            $response['action']                 = 'get_friend';
            return $response;
        }

        return ['success' => false, 'message' => 'Please try again.'];
    }

    /**
     * Change Friend Request view status
     *
     * @param string $clearType
     * @param object $user
     * @param int $responseId
     * @param int $status
     * @return array
     */
    public function clearFriendRequest($clearType, $user, $responseId, $status)
    {
        $friend = false;

        // Will return true if successful
        $friend = $this->friend->clearFriendReuest($clearType, $user, $responseId, $status);

        if ($friend) {
            return ['success' => true, 'message' => 'You have successfully update Friend Requset view status.'];
        }

        return ['success' => false, 'message' => 'Please try again.'];
    }
}