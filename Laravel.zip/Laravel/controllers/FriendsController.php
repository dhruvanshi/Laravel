<?php

use Jivial\Services\FriendShipService;
use Jivial\Repositories\FriendRepository;
use Jivial\Services\MailService;

class FriendsController extends BaseController {

    /**
     * Friend Service container
     *
     * @var FriendShipService
     */
    protected $friend;

    /**
     * Friend Repositories container
     *
     * @var FriendRepository
     */
    protected $friendRep;

    /**
     * Mail Service container
     *
     * @var MailService
     */
    protected $email;

    /**
     * Init dependencies
     *
     * @param FriendShipService $friend
     * @param FriendRepository $friendRep
     * @param MailService $email
     */
    public function __construct( FriendShipService $friend, FriendRepository $friendRep, MailService $email)
    {
        $this->friend = $friend;
        $this->friendRep = $friendRep;
        $this->email  = $email;
    }

    /**
     * Show Friends
     *
     * @return View
     */
    public function getIndex()
    {
        $user = Auth::user();

        return View::make('friends.index')
                    ->withAllFriends($user->all_friends)
                    ->withCloseFriends($user->close_friends)
                    ->withFriends($user->friends)
                    ->withAcquaintances($user->acquaintances);
    }

    /**
     * Change friend relation and unfriend.
     *
     * @return json
     */
    public function changeFriendRelation()
    {
        $user = Auth::user();
        $friendId = Input::get('friend_id');
        $friendRelation = Input::get('friend_relation');
        if($friendRelation != 'Unfriend') {
            $response = $this->friend->updateFriend($user, $friendId, $friendRelation);
        } else {
            $response = $this->friend->unFriend($user, $friendId);
        }

        if (Request::ajax()) {
            return Response::json($response);
        } else {
            return Redirect::to('/')->with('flash', $response);
        }

    }

    /**
     * View Friend Request
     *
     * @return View
     */
    public function request()
    {
        $user = Auth::user();

        return View::make('friend_request')
                    ->withAllFriendRequestOther($user->open_friend_requests_other)
                    ->withAllFriendRequestMe($user->open_friend_requests_me);
    }

    /**
     * Change friend request
     *
     * @return json
     */
    public function requestStatus()
    {
        // accept friend request
        $user = Auth::user();
        $fromId         = Input::get('from_id');
        $response       = Input::get('response');
        $friendType     = Input::get('friend_type');

        $clearType = Input::get('clear_type');

        if ($clearType) {
            $responseId = Input::get('response_id');
            $status = 0;
            $response = $this->friend->clearFriendRequest($clearType, $user, $responseId, $status);
        } else {
            if ($response == 'ACCEPT') {
                $status = 1;
                $response = $this->friend->acceptFriendRequest($user, $fromId, $status, $friendType);

                //send mail friend request accept.
                $img = $user->img_url ?: 'no-profile-pic.png';

                $requseterUser = $this->friendRep->getUserById($fromId);
                $emailData = [
                    'userName'      => $user->full_name,
                    'userUrl'       => URL::route('topics', $user->slug),
                    'image'         => image($img)
                ];

                $email =  $requseterUser->email;
                $this->email->acceptFriendRequest($email, $emailData);
            } else {
                $status = 2;
                $response = $this->friend->declineFriendRequest($user, $fromId, $status);
            }
        }

        if (Request::ajax()) {
            return Response::json($response);
        } else {
            return Redirect::to('/')->with('flash', $response);
        }
    }

    /**
     * Search friend
     *
     * @return json
     */
    public function search()
    {
        $user = Auth::user();
        $q      = Input::get('q');

        $response = $this->friend->searchFriend($user, $q);

        return Response::json($response);
    }

    /**
     * Get friend by Friend Id
     *
     * @return mixed
     */
    public function searchFriend()
    {
        $user     = Auth::user();
        $friendId = Input::get('friend_id');

        $response = $this->friend->getFriendByFriendId($user, $friendId);

        if (Request::ajax()) {
            return Response::json($response);
        } else {
            return Redirect::to('/')->with('flash', $response);
        }
    }
}