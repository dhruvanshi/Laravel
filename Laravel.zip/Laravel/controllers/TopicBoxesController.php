<?php

use Jivial\Services\MailService;
use Jivial\Repositories\TopicBoxRepository;
use Jivial\Repositories\UserRepository;
use Jivial\Repositories\CategoryRepository;
use Jivial\Repositories\ColorRepository;

class TopicBoxesController extends BaseController
{

    /**
     * User repository
     *
     * @var UserRepository
     */
    protected $user;

    /**
     * Topic Box Repository
     *
     * @var TopicBoxRepository
     */
    protected $topic;

    /**
     * Mail Service container
     *
     * @var MailService
     */
    protected $email;

    /**
     * Category Service Container
     *
     * @var CategoryService
     */
    protected $category;

    /**
     * Color Repository container
     *
     * @var ColorRepository
     */
    protected $color;

    /**
     * Class constructor
     *
     * @param UserRepository      $user
     * @param TopicBoxRepository  $topic
     * @param MailService         $email
     * @param CategoryRepository  $category
     * @param ColorRepository     $color
     */
    public function __construct(UserRepository $user, TopicBoxRepository $topic, MailService $email, CategoryRepository $category, ColorRepository $color)
    {
        $this->user     = $user;
        $this->topic    = $topic;
        $this->email    = $email;
        $this->category = $category;
        $this->color    = $color;
    }

    /**
     * Show main topic page
     *
     * @return  View
     */
    public function getIndex($userSlug)
    {
        $currentUserId = Session::get('user_id');
        $userId        = Request::userId();
        $categories    = $this->category->getForUserId($userId);
        $topicBoxes    = $this->topic->allByUserId($userId);
        $category      = null;
        $colors        = $this->color->getColor();

        // Get friend status
        if ($currentUserId == $userId) {
            $friendStatus = ['friend_status' => 'own_topic_box'];
        }
        else {
            $friendStatus = $this->topic->getFriendStatus($currentUserId, $userId);
        }

        return View::make('topic_boxes.index')
                   ->withTopicBoxes($topicBoxes)
                   ->withFriendStatus($friendStatus)
                   ->withCategories($categories)
                   ->withCategory($category)
                   ->withColors($colors);
    }

    /**
     * Save new topic box
     *
     * @return Response JSON response
     */
    public function storeNewBox()
    {
        $userId = Session::get('user_id');
        $input  = Input::all();

        if ( ! $input['topic_slug']) {
            $response = $this->topic->saveNewTopicBox($userId, $input);
        }
        else {
            $topic = $this->topic->getTopicBoxesForTopicSlug($input['topic_slug'], $userId);
            $response = $this->topic->updateTopicBox($userId, $input, $topic['id']);
        }

        if (isset($response['errors'])) {
            $errors = $response['errors'];
            unset($response['errors']);
            foreach ($input as $key=>$value) {
                if ($errors->has($key))  {
                    $response[$key.'_error'] = $errors->first($key);
                }
            }
        }
        else {
            if (isset($response['topic_slug'])) {
                $response['url'] = URL::route('topics.entries.create', [$response['user_slug'], $response['topic_slug']]);
                unset($response['user_slug']);
                unset($response['topic_slug']);
            }
        }

        return Response::json($response);
    }

    /**
     * New entry
     * @todo proper comment needed
     */
    public function newEntry()
    {
        return View::make('entry');
    }

    /**
     * Show selected Category Topic Boxes Page
     *
     * @param $categorySlug
     * @return mixed
     */
    public function viewTopicsByCategory($userSlug, $categorySlug)
    {
        $currentUserId = Session::get('user_id');
        $userId        = Request::userId();
        $categories    = $this->category->getForUserId($userId);
        $topicBoxes    = $this->topic->getTopicBoxesByUserIdAndCategory($userId, $categorySlug);
        $category      = $this->category->getBySlugAndUserId($categorySlug, $userId);

        // Get friend status
        if ($currentUserId == $userId) $friendStatus = ['friend_status' => 'own_topic_box'];
        else                           $friendStatus = $this->topic->getFriendStatus($currentUserId, $userId);

        return View::make('topic_boxes.index')
                   ->withTopicBoxes($topicBoxes)
                   ->withFriendStatus($friendStatus)
                   ->withCategories($categories)
                   ->withCategory($category);


        return View::make('topic_boxes.index', compact('user_details','topic_boxes','friend_status'));
    }

    /**
     * Friend request get
     *
     * @return Response or Redirect
     */
    public function friendRequest()
    {
        $data = [
            'user_id'     => Session::get('user_id'),
            'friend_id'   => Input::get('friend_id'),
            'message'     => Input::get('request_note'),
            'friend_type' => Input::get('fr_type'),
            'friend_name' => Input::get('friend_name')
        ];

        $response = $this->topic->friendRequest($data);

        //send invitation email
        $currentUser = Auth::user();
        $img = $currentUser->img_url ?: 'no-profile-pic.png';

        $requsetUser = $this->user->getUserById($data['friend_id']);
        $emailData = [
            'userName'      => $currentUser->full_name,
            'userUrl'       => route('topics', $currentUser->slug),
            'messageTxt'    => $data['message'],
            'image'         => image($img),
            'requestUrl'    => route('friends.request', $requsetUser['slug'])
        ];

        $email = $requsetUser['email'];
        $this->email->sendTopicFriendRequest($email, $emailData);

        if (Request::ajax()) return Response::json($response);
        else                 return Redirect::to('/')->with('flash', $response);
    }

    /**
     * Get Edit Topic Data
     *
     * @param string $topicSlug
     * @return mixed
     */
    public function getEditTopic($userSlug, $topicSlug)
    {
        $userId   = Request::userId();
        $response = $this->topic->getTopicBoxesForTopicSlug($topicSlug, $userId);

        $response['action']     = 'topic-get-edit';
        $response['delete_url'] = URL::route('deleteTopicBox', [$userSlug, $response['slug']]);

        if (Request::ajax()) return Response::json($response);
        else                 return Redirect::to('/')->with('flash', $response);
    }

    /**
     * Delete Topic Box
     *
     * @param string $topicSlug
     * @return mixed
     */
    public function deleteTopicBox($userSlug, $topicSlug)
    {
        $userId   = Session::get('user_id');
        $response = $this->topic->deleteTopicBox($topicSlug, $userId);

        if (Request::ajax()) return Response::json($response);
        else                 return Redirect::to('/')->with('flash', $response);
    }

    /**
     * Create New Custom Category
     *
     * @return mixed
     */
    public function storeCustomCategory()
    {
        $userId   = Session::get('user_id');
        $response = $this->category->storeCustomCategory($userId, Input::all());

        if (Request::ajax()) return Response::json($response);
        else                 return Redirect::to('/')->with('flash', $response);
    }

}