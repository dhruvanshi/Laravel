<!DOCTYPE html>
<html class="no-js">
<head>
	@include('_partials.meta')

	@include('_partials.assets_head')
</head>
<body>
@include('_partials.outdated')

<header>
	<div class="container">
		<div class="row">
			<div class="col-md-3">
				<h1><a href="{{ route('dashboard', $user_slug) }}"><img src="{{ image('header-logo.png') }}" alt="Jivial"/></a></h1>
			</div>

			<div class="col-md-5 col-md-offset-1 text-center">
				@include('_partials.search_header')
			</div>

			<div class="col-md-3 user-info">
				@include('_partials.auth_header')
			</div>
		</div>
	</div>
</header>

@include('_partials.navigation')

<div class="container" id="content">
	<div class="col-sm-9">
		@yield('content')
	</div>

	<div class="col-sm-3 modules">
		@section('sidebar')
			@include('_partials.aside')
		@show
	</div>
</div>

@include('_partials.footer')

@include('_partials.assets_footer')

@include('_partials.analytics')

</body>
</html>
