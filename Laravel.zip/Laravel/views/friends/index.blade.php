@extends('_layouts.master')

@section('js-include')
@parent
<script src="/js/template.js"></script>
<script src="/js/local/friends.js"></script>

@stop

@section('content')
<div class="friends">

    <ul class="nav nav-tabs nav-justified">
        <li class="active"><a href="#all-friends" data-toggle="tab">All Friends</a></li>
        <li class=""><a href="#close-friends" data-toggle="tab">Close Friends</a></li>
        <li class=""><a href="#friends" data-toggle="tab">Friends</a></li>
        <li class=""><a href="#acquaintances" data-toggle="tab">Acquaintences</a></li>
    </ul>

    <div class="tab-content">
        <div class="text-center search-form friends-search gray-background">
            <input id="friend-search" type="text" placeholder="FIND A FRIEND" class="form-control input-sm search-term"/>
            <input type="hidden" id="search-url" value="{{ route('friends', $user->slug) }}/search">
            <a href="{{ route('friends', $user->slug) }}" class="clear-search form-control">X</a>
            <a href="#" class="search-site form-control"><span class="glyphicon glyphicon-search"</span></a>
            <div class="pull-right">
                <ul class="notifications">
                    <li class="active no-margin"><span class="topic-box"></span> Topic Box Invites - 1</li>
                    <li class="active no-margin"><a href="{{ route('friends.request', $user->slug) }}"><span class="glyphicon glyphicon-user"></span> Friend Requests - {{ isset($friendRequest) ? $friendRequest : 0 }}</a></li>
                </ul>
            </div>
        </div>
        @include('friends.partials.all_friends')
        @include('friends.partials.close_friends')
        @include('friends.partials.friends')
        @include('friends.partials.friends')
        @include('friends.partials.acquaintances')
        @include('friends.partials.browse_all')

    </div>
    @include('friends.partials.modal_unfriend')
</div>

@include('friends.partials.popover_friend')
@stop