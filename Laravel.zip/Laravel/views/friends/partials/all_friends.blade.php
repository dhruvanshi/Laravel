<div class="tab-pane active" id="all-friends">
    <div class="row clearfix">
        @if ($all_friends->count() > 0)
            @foreach ($all_friends->chunk(5) as $row)
                @foreach ($row as $friend)
                <div class="col-sm-2 friend-profile" rel="friend-{{ md5($friend->id) }}" data-title="{{ $friend->full_name }}">
                    <div class="profile">
                        <a href="{{ route('topics', ['userslug' => $friend->slug]) }}">
                            <img src="{{ $friend->image }}" class="img-responsive profile-pic pull-left" />
                        </a>
                        <div class="friend-select" data-placement="bottom" title="test">
                            <span class="glyphicon glyphicon-chevron-right"></span>
                            <span class="friend-selection" data-url="{{ route('friends.change_relation', ['userslug' => $friend->slug]) }}" data-id="{{ $friend->id }}" data-title="{{ $friend->relationship_type }}">{{ $friend->relationship_type }}</span>
                        </div>
                    </div>
                    <div class="name">
                        <span data-title="{{ $friend->full_name }}">{{ $friend->full_name }}</span>
                    </div>
                </div>
                @endforeach
            @endforeach
        @else
            <div class="col-sm-7 friend-empty">
                <p>So far you do not have any friends on Jivial. </p>
                <p>To send out friend requests and invitations to join Jivial, click on the "Invite Subscirbers" button within each Topic Box you create. After you write and publish your first Entry, your invitations will be sent out.</p>
            </div>
        @endif
    </div>
</div>