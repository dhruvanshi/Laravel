<div class="tab-pane" id="browse-all">
    <div class="row">
        <div class="col-sm-2 friend-profile">
            <div class="profile">
                <img class="profile-pic" src="{{ image('profile-pic.png') }}" class="img-responsive profile-pic pull-left" />
                <div class="friend-select" data-placement="bottom" title="test">
                    <span class="glyphicon glyphicon-chevron-right"></span>
                    <span class="friend-selection">Friend</span>
                </div>
            </div>
            <div class="name">
                <span>Sean Charboneau</span>
            </div>
        </div>
        <div class="col-sm-2">
            <div class="profile">
                <img class="profile-pic" src="{{ image('profile-pic.png') }}" class="img-responsive profile-pic pull-left" />
                <div class="friend-select" data-placement="bottom" title="test">
                    <span class="glyphicon glyphicon-chevron-right"></span>
                    <span class="friend-selection">Friend</span>
                </div>
            </div>
            <div class="name">
                <span>Sean Charboneau</span>
            </div>
        </div>
        <div class="col-sm-2">
            <div class="profile">
                <img class="profile-pic" src="{{ image('profile-pic.png') }}" class="img-responsive profile-pic pull-left" />
                <div class="friend-select" data-placement="bottom" title="test">
                    <span class="glyphicon glyphicon-chevron-right"></span>
                    <span class="friend-selection">Friend</span>
                </div>
            </div>
            <div class="name">
                <span>Sean Charboneau</span>
            </div>
        </div>
        <div class="col-sm-2">
            <div class="profile">
                <img class="profile-pic" src="{{ image('profile-pic.png') }}" class="img-responsive profile-pic pull-left" />
                <div class="friend-select" data-placement="bottom" title="test">
                    <span class="glyphicon glyphicon-chevron-right"></span>
                    <span class="friend-selection">Friend</span>
                </div>
            </div>
            <div class="name">
                <span>Sean Charboneau</span>
            </div>
        </div>
        <div class="col-sm-2">
            <div class="profile">
                <img class="profile-pic" src="{{ image('profile-pic.png') }}" class="img-responsive profile-pic pull-left" />
                <div class="friend-select" data-placement="bottom" title="test">
                    <span class="glyphicon glyphicon-chevron-right"></span>
                    <span class="friend-selection">Friend</span>
                </div>
            </div>
            <div class="name">
                <span>Sean Charboneau</span>
            </div>
        </div>
    </div>
</div>