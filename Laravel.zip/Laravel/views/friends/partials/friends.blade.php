<div class="tab-pane" id="friends">
    <div class="row">
        @if ($friends->count() > 0)
            @foreach ($friends->chunk(5) as $row)
                @foreach ($row as $friend)
                <div class="col-sm-2 friend-profile" rel="friend-{{ md5($friend->id) }}" data-title="{{ $friend->full_name }}">
                    <div class="profile">
                        <a href="{{ route('topics', ['userslug' => $friend->slug]) }}">
                            <img src="{{ $friend->image }}" class="img-responsive profile-pic pull-left" />
                        </a>
                        <div class="friend-select" data-placement="bottom" title="test">
                            <span class="glyphicon glyphicon-chevron-right"></span>
                            <span class="friend-selection" data-url="{{ route('friends.change_relation', ['userslug' => $friend->slug]) }}" data-title="{{ $friend->relationship_type }}" data-id="{{ $friend->id }}">{{ $friend->relationship_type }}</span>
                        </div>
                    </div>
                    <div class="name">
                        <span data-title="{{ $friend->full_name }}">{{ $friend->full_name }}</span>
                    </div>
                </div>
                @endforeach
            @endforeach
        @else
            <div class="col-sm-7 friend-empty">
                <p>This page has no one on it.</p>
            </div>
        @endif
    </div>
</div>