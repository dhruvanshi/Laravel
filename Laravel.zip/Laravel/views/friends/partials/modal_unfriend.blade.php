<div id="unfriend-modal" class="modal fade alert">
    <div class="modal-dialog modal-sm">
        <div class="modal-content">
            <div class="modal-header"></div>
            <div class="modal-body text-center">
                <div class="delete-message">
                    <p>Are you sure that you want to remove <span id="unfriend-friend-name">friend_name</span> from your list of friends?</p>
                    <button class="btn btn-jivial" data-dismiss="modal">Cancel</button>
                    <button class="btn btn-jivial blue-light" id="unfriend_confirm">Yes</button>
                </div>
            </div>
            <div class="modal-footer"></div>
        </div>
    </div>
</div>