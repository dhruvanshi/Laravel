
<div id="popover-content" class="hide">
    <ul>
        <li data-title="Close Friend">Close Friend</li>
        <li data-title="Friend">Friend</li>
        <li data-title="Acquaintance">Acquaintance</li>
        <li class="unfriend" data-title="Unfriend">Unfriend</li>
    </ul>
</div>